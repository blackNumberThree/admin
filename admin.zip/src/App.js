import React, { Component } from 'react';
import './App.css';
import Main from './components/main.js';
import Authorization from './components/authorization.js';

import {BrowserRouter as Router,  Route} from 'react-router-dom';

class App extends Component{
      state = {
       displayPage : this.page
      }

	
	  page = (sessionStorage.getItem('securety'))?Main:Authorization;
		   


	// if (false) {page = Main}else{page = Authorization}
   
   render(){
  return(


      <Router>
            <Route path= "/"  component = {this.page}/>
      </Router>
             );
}}

export default App;
