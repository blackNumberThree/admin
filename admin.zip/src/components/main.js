import React, { Component } from 'react';
import './main.css';
import Chat from './chat.js';
import io from "socket.io-client";

class Main extends Component{
      state = {
      	rooms:[],
      	current_room:'Admin',
        userInfo:{ 
          author:"-",
          auth_phone:"--",
          auth_contact_number:"---",
          auth_balance:"----",
          auth_tariff_inet:"-----", 
          auth_address:"-----" 

        }
           }
    //Создание переменных//
        //===========================******************========================================
       socket = io.connect('https://webiraylab.eu-4.evennode.com/');
        //подключение нового канала
        //создание нового канала
      newUser =  (name) =>  { this.socket.emit('ADD_USER',"Admin", {
          author:"-",
          auth_phone:"--",
          auth_contact_number:"---",
          auth_balance:"----",
          auth_tariff_inet:"-----",
          auth_address:"-----" 
        }) }

        newConnect =  this.socket.on('connect', this.newUser )
    		changeRoom = (data,data_2) => { 
            if (data_2) {
               localStorage.setItem('current_room', this.state.current_room);
                 this.setState( {rooms: [ ...data]} ); 
                        }
                else{ this.setState(  {rooms:[ ...data]} ) } 
              };
     	  roomListening = this.socket.on('UPDATE_ROOMS', this.changeRoom );

        userInfo=(data)=>{ 

          this.setState(  {userInfo:{
          author:data.author,
          auth_phone:data.auth_phone,
          auth_contact_number:data.auth_contact_number,
          auth_balance:data.auth_balance,
          auth_tariff_inet:data.auth_tariff_inet,
          auth_address:data.auth_address

        }} ) 
         console.log(this.state)
         }
        catchInfo = this.socket.on('USER-INFO', this.userInfo);


      // Создаем событие "смена комнаты"
	    	switchRoom = (ev) =>{
          this.socket.emit('SWITCH_ROOM', ev.target.innerText);
          this.setState( {rooms: [], current_room:ev.target.innerText } );          
       };

    //=======================***************========================================

     deleteRoom = () =>  {
          if (this.state.current_room==='Admin') {alert(`don't do it! (◣_◢)`)} 
        else {
            this.setState(  {current_room:'Admin'} ); 
            this.socket.emit('DETELE_ROOM', this.state.current_room)
            this.socket.emit('SWITCH_ROOM', 'Admin')

       } 
     }

   render(){
  return(
      <>
  <header className="header">
    <div className="header__main">
      <div className="header__leftside">
        <span className="header__tech-text">{'Заявки в техническую поддержку'}</span>
          <div className="header__chats-row chats-row">

              
        
          {
              this.state.rooms.map(room => {
                        if (room===this.state.current_room) { 
                        	return (<div key={room} className='chats-row__pop-up_active'>{room}</div>) }
						else
                       { return( <div key={ toString(Symbol()) } className='chats-row__pop-up' onClick={this.switchRoom}>{room}</div>) }
                		
            })}

 			<div className="chats-row__pop-up-hidden">
                <img className ="header__rectangle-img" src={require('../img/rectangle.png')} alt="img"/>
              </div>
              
          </div>
      </div>
    
  </div>
</header>

<main className="main-chat" >


  <Chat socket= {this.socket}/>



    <div className="main__right-side right-side">

      <div className="right-side__buttons">
        <p onClick={this.deleteRoom}> Завершить разговор</p>
      </div>


      <div className="right-side__blank">
        <div className="right-side__row_short" >

          <div className="right-side__row">
            <p className="right-side__row-title">Номер договора</p>
            <input type="text" name=""  value={this.state.userInfo.auth_contact_number} readOnly="readonly"/>
          </div>

          <div className="right-side__row">
                    <p className="right-side__row-title">Баланс</p>
                    <span className="right-side__balance">{this.state.userInfo.auth_balance} ₽</span>
          </div>

        </div>

        <div className="right-side__row">
          <p className="right-side__row-title">Тариф</p>
          <input type="text" name=""  value={this.state.userInfo.auth_tariff_inet} readOnly="readonly"/>
        </div>

        <div className="right-side__row">
          <p className="right-side__row-title"> ФИО абонента</p>
          <input type="text" name=""  value={this.state.userInfo.author} readOnly="readonly"/>
        </div>

        <div className="right-side__row">
          <p className="right-side__row-title">Адрес</p>
          <input type="text" name=""  value={this.state.userInfo.auth_address} readOnly="readonly"/>
        </div>

        <div className="right-side__row" >

          <div className="right-side__row">
            <p className="right-side__row-title">Контактные телефоны</p>
            <input type="text" name=""  value={this.state.userInfo.auth_phone} readOnly="readonly"/>
          </div>

         

        </div>



        </div>



    </div>
    </main>
    </>
  )
}}

export default Main;

     /* <div className="chats-row__pop-up">
                <span>185120</span>
                <span className="chats-row__new-mesedge">3</span>
              </div>*/