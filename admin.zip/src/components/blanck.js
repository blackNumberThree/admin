import React from 'react';
import './blanck.css';

const Blanck =()=>{
  return(
<>



<header className="header">
  <div className="header__main">
    <div className="header__leftside">
      <span className="header__tech-text">Чат технической поддержки</span>
      <div className="header__chats-row chats-row">
         <div className="chats-row__pop-up">
            185120
         </div>
         <div className="chats-row__pop-up">
             185120
          </div>
          <div className="chats-row__pop-up_active">
             188199
         </div>
         <div className="chats-row__pop-up">
             <span>185120</span> <span className="chats-row__new-mesedge">3</span>
         </div>
         <div className="chats-row__pop-up">
             185120
         </div>
         <div className="chats-row__pop-up">
             185120
         </div> 
         <div className="chats-row__pop-up">
            185120
        </div>
        <div className="chats-row__pop-up">
            185120
        </div>
        <div className="chats-row__pop-up">
            185120
        </div>
        <div className="chats-row__pop-up-hidden">
           <img className ="header__rectangle-img" src={require('../img/rectangle.png')} alt="img"/>
       </div>
    </div>
    </div>
     <div className ="header__avatar">
           <span className ="header__avatar-text" >Милакова ЖА</span>
          <img className ="header__avatar-img" src={require('../img/ava.png')} alt="ava"/>
      </div>
  </div>
</header>

<main>
  <div className="blanck-wrapper">
    <div className="blank">
      <div className="blank__row_short" >

        <div className="blank__row">
          <p className="blank__row-title">Номер договора</p>
          <input type="text" name=""  value="150180" readOnly="readonly"/>
        </div>

        <div className="blank__row">
           <p className="blank__row-title">Баланс</p>
           <span className="blank__balance">990,0</span>
        </div>

        </div>

        <div className="blank__row">
          <p className="blank__row-title">Тариф</p>
          <input type="text" name=""  value="Форсаж 200 Абонемент" readOnly="readonly"/>
        </div>

        <div className="blank__row">
           <p className="blank__row-title"> ФИО абонента</p>
           <input type="text" name=""  value="Иванова Ирина Ивановна" readOnly="readonly"/>
         </div>
 
         <div className="blank__row">
           <p className="blank__row-title">Адрес</p>
           <input type="text" name=""  value="Всеволожск, Алексеевский проспект 21Ж " readOnly="readonly"/>
         </div>

          <div className="blank__row_short" >

            <div className="blank__row">
              <p className="blank__row-title">Контактные телефоны</p>
              <input type="text" name=""  value="+7 (921) 900 00 00 " readOnly="readonly"/>
            </div>

            <div className="blank__row_low">
                <input type="text" name=""  value="+7 (921) 900 00 00 " readOnly="readonly"/>
            </div>

          </div>

        </div>
              <div className="blank__button">
              <p> Завершить разговор</p>
      </div>
    </div>

    <div className="blanck-wrapper">

       <div className="blank">

          <div className="blank__row">
             <p className="blank__row-title">Номер заявки</p>
              <input type="text" name=""  value="Заявка Ч1000" readOnly="readonly"/>
           </div>

           <div className="blank__row">
              <p className="blank__row-title"> Адрес</p>
              <input type="text" name=""  value=" Алексеевский 21Ж" readOnly="readonly"/>
            </div>

             <div className="blank__row">
               <p className="blank__row-title">Вид услуги</p>
               <select className="blanck__service">
                  <option className="blanck__service">Ремонт x1</option>
                  <option className="blanck__service">Ремонт x2</option>
                  <option className="blanck__service">Ремонт x3</option>
                  <option className="blanck__service">Подключение</option>
                </select>
              </div>

              <div className="blank__row" >
                <div className="blank__row">
                   <p className="blank__row-title">Коментарии</p>
                    <textarea className="blanck__coments" name="name" rows="9" cols="43"></textarea>
               </div>
            </div>
          </div>
          <div className="blank__button">
            <p> Завершить разговор</p>
         </div>
        </div>
    </main>


    </>
  )
}

export default Blanck;
