// Подключение всех модулей к программе
var express = require('express');
var socket = require('socket.io');
//создание сервера
var app = express();
// прослушивание экспрес сервера и создание на нем сокет сервера
io = socket(server);




// подписка на событие, навес на событиеколбека
io.on('connection', (socket) => {

socket.on('MESSAGE', function(data){

  io.emit('RECEIVE_MESSAGE', data);

})
//прослушывание  события сенд меседж на стороне клиента  при котором передаем серверу 2 аргументом сообщение

});

// Отслеживание порта(запуск после )
server = app.listen(5000,console.log('server is running on port 3000'));